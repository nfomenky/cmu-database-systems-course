--- Count the number of attorneys

select count(distinct(name)) 
from attorneys
;
